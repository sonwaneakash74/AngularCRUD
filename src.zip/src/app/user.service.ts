import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './user';
import { Observable } from 'rxjs';
import { identifierModuleUrl } from '@angular/compiler';


@Injectable({
  providedIn: 'root'
})
export class UserService {

  private usersUrl: string;
  private user: User;

  constructor(private http: HttpClient) {
    this.usersUrl = 'http://localhost:8080/users';
  }

  public findAll(): Observable<User[]> {
    return this.http.get<User[]>(this.usersUrl);
  }

  public save(user: User) {
    return this.http.post<User>(this.usersUrl, user);
  }

  public delete(id:any){
    return this.http.delete("http://localhost:8080/delete/"+id).subscribe(data => {
      console.log(data);
    });
  }

  public getUserByID(id): Observable<User> {
    return this.http.get<User>(this.usersUrl+"/"+id);
  }
}