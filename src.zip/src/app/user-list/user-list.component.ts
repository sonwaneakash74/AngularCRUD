import { Component, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { SharedserviceService } from '../sharedservice.service';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {

  users: User[];

  constructor(private userService: UserService, private sharedservice: SharedserviceService, 
    private router: Router) {
  }

  ngOnInit() {
    this.userService.findAll().subscribe(data => {
      this.users = data;
    });
  }

  deleteEmployee(id: any)
  {
    this.userService.delete(id);
    window.location.reload() 
  }

  UpdateEmployee(id: any)
  {
    this.sharedservice.saveUserId(id);
    this.router.navigate(['update']);
  }
}
