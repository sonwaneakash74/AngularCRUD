import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SharedserviceService {

  id:any;
  constructor() { }

  public saveUserId(id:any)
  {
    this.id=id;
  }

  public getUserId()
  {
    return this.id;
  }


}
