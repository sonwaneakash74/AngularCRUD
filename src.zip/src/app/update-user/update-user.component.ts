import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SharedserviceService } from '../sharedservice.service';
import { User } from '../user';
import { UserService } from '../user.service';

@Component({
  selector: 'app-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.css']
})
export class UpdateUserComponent implements OnInit {

  id:any;
  user: User;
  
  constructor(private router: Router, private sharedservice: SharedserviceService,
     private userService: UserService) { }

  ngOnInit() {
    this.id=this.sharedservice.getUserId();
    this.userService.getUserByID(this.id).subscribe(data=>{this.user= data})
  }

  onSubmit() {
    this.userService.save(this.user).subscribe(result => this.gotoUserList());
  }

  gotoUserList() {
    this.router.navigate(['/users']);
  }
}
